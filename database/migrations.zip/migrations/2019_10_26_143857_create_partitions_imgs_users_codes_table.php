<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreatePartitionsImgsUsersCodesTable extends Migration {

	public function up()
	{
		Schema::create('partitions_imgs_users_codes', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->integer('partitions_imgs_id')->nullable();
			$table->integer('statue')->nullable();
			$table->integer('users_id');
		});
	}

	public function down()
	{
		Schema::drop('partitions_imgs_users_codes');
	}
}