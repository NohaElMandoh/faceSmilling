<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateCaptureImgsTable extends Migration {

	public function up()
	{
		Schema::create('capture_imgs', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->string('path', 100)->nullable();
			$table->string('face_status_id')->nullable();
			$table->string('ellapsed_time', 50)->nullable();
			$table->string('matching')->nullable();
			$table->integer('users_id')->unsigned();
		});
	}

	public function down()
	{
		Schema::drop('capture_imgs');
	}
}