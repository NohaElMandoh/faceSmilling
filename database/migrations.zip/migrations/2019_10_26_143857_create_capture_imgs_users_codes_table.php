<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateCaptureImgsUsersCodesTable extends Migration {

	public function up()
	{
		Schema::create('capture_imgs_users_codes', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->integer('capture_imgs_id');
			$table->integer('users_id')->unsigned();
			$table->integer('status');
		});
	}

	public function down()
	{
		Schema::drop('capture_imgs_users_codes');
	}
}