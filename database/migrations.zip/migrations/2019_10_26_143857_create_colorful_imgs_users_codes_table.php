<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateColorfulImgsUsersCodesTable extends Migration {

	public function up()
	{
		Schema::create('colorful_imgs_users_codes', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->integer('colorful_imgs_id')->nullable();
			$table->integer('status')->nullable();
			$table->integer('users_id');
		});
	}

	public function down()
	{
		Schema::drop('colorful_imgs_users_codes');
	}
}