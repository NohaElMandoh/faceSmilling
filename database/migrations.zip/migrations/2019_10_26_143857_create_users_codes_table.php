<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateUsersCodesTable extends Migration {

	public function up()
	{
		Schema::create('users_codes', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->integer('users_id');
			$table->string('code', 191);
		});
	}

	public function down()
	{
		Schema::drop('users_codes');
	}
}